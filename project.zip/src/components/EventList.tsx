import { useState, useEffect } from 'react';
import { toast } from 'react-hot-toast';
import { format } from 'date-fns';
import { id as localeId } from 'date-fns/locale';
import { Search, RefreshCw, Calendar, MapPin, ArrowUpDown, ChevronLeft, ChevronRight, Inbox } from 'lucide-react';
import { api } from '../services/api';
import { storage } from '../services/storage';
import { EventData } from '../types';

export const EventList = () => {
  const [events, setEvents] = useState<EventData[]>(() => storage.getEvents());
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [page, setPage] = useState(1);
  const itemsPerPage = 5;

  const fetchEvents = async (manual = false) => {
    setLoading(true);
    try {
      const data = await api.getEvents();
      // Ensure unique IDs if the API returns duplicates
      const uniqueEvents = Array.from(new Map(data.map(item => [item.id, item])).values());
      
      setEvents(uniqueEvents);
      storage.saveEvents(uniqueEvents);
      storage.setLastSync(Date.now());
      
      if (manual) {
        toast.success('Data berhasil disinkronisasi');
      }
    } catch (error) {
      console.error(error);
      // Don't show error toast on auto-sync to avoid annoyance, only on manual
      if (manual) {
        toast.error('Gagal mengambil data acara');
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // 1. Initial check: should we sync?
    const lastSync = storage.getLastSync();
    const now = Date.now();
    const tenMinutes = 10 * 60 * 1000;

    // Fetch if no cache, expired cache, or last sync is invalid/missing (force refresh)
    if (!lastSync || now - lastSync > tenMinutes || events.length === 0) {
      fetchEvents(false);
    }

    // 2. Set interval for auto-sync every 10 minutes
    const intervalId = setInterval(() => {
      fetchEvents(false);
    }, tenMinutes);

    return () => clearInterval(intervalId);
  }, []);

  const filteredEvents = events
    .filter(event => 
      (event.namaAcara?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
      (event.lokasi?.toLowerCase() || '').includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => {
      const dateA = new Date(a.tanggalWaktu).getTime();
      const dateB = new Date(b.tanggalWaktu).getTime();
      return sortOrder === 'asc' ? dateA - dateB : dateB - dateA;
    });

  const totalPages = Math.ceil(filteredEvents.length / itemsPerPage);
  const currentEvents = filteredEvents.slice((page - 1) * itemsPerPage, page * itemsPerPage);

  return (
    <div className="bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 overflow-hidden flex flex-col h-full">
      <div className="p-6 border-b border-slate-200 dark:border-slate-700">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <h2 className="text-2xl font-bold text-slate-800 dark:text-white flex items-center gap-2">
            <Calendar className="w-6 h-6 text-blue-600" />
            Daftar Acara
          </h2>
          <div className="flex items-center gap-3">
             {loading && events.length > 0 && (
               <span className="text-sm text-slate-500 animate-pulse hidden md:inline-block">
                 Menyinkronkan data...
               </span>
             )}
            <button
              onClick={() => fetchEvents(true)}
              disabled={loading}
              className="flex items-center justify-center gap-2 px-4 py-2 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 rounded-lg transition-colors"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              Sinkron Data
            </button>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              placeholder="Cari acara..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-slate-300 dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white dark:bg-slate-700 text-slate-900 dark:text-white"
            />
          </div>
          <button
            onClick={() => setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc')}
            className="flex items-center gap-2 px-4 py-2 border border-slate-300 dark:border-slate-600 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200"
          >
            <ArrowUpDown className="w-4 h-4" />
            {sortOrder === 'asc' ? 'Terlama' : 'Terbaru'}
          </button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-slate-50 dark:bg-slate-900/50 text-left">
            <tr>
              <th className="px-6 py-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">ID & Nama Acara</th>
              <th className="px-6 py-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Waktu & Tempat</th>
              <th className="px-6 py-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Dresscode</th>
              <th className="px-6 py-4 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Aksi</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
            {loading && events.length === 0 ? (
              <tr>
                <td colSpan={4} className="px-6 py-12 text-center">
                   <div className="flex justify-center items-center gap-2 text-slate-500">
                     <RefreshCw className="w-5 h-5 animate-spin" />
                     Memuat data...
                   </div>
                </td>
              </tr>
            ) : currentEvents.length === 0 ? (
              <tr>
                <td colSpan={4} className="px-6 py-12 text-center">
                  <div className="flex flex-col items-center gap-2 text-slate-500">
                    <Inbox className="w-10 h-10 opacity-50" />
                    <p>Belum ada acara yang terdaftar</p>
                  </div>
                </td>
              </tr>
            ) : (
              currentEvents.map((event) => (
                <tr key={event.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex flex-col">
                      <span className="text-xs font-mono text-slate-500 mb-1">#{event.id}</span>
                      <span className="font-semibold text-slate-900 dark:text-white">{event.namaAcara}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300">
                        <Calendar className="w-4 h-4" />
                        {event.tanggalWaktu ? format(new Date(event.tanggalWaktu), 'dd MMMM yyyy, HH:mm', { locale: localeId }) : '-'}
                      </div>
                      <div className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300">
                        <MapPin className="w-4 h-4" />
                        <span className="truncate max-w-[200px]">{event.lokasi}</span>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                      ${event.dresscode === 'Formal' ? 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200' :
                        event.dresscode === 'Semi-Formal' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200' :
                        event.dresscode === 'Casual' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' :
                        'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200'
                      }`}>
                      {event.dresscode}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                     <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                       Detail
                     </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      
      {/* Pagination */}
      {totalPages > 1 && (
        <div className="px-6 py-4 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between">
           <span className="text-sm text-slate-500 dark:text-slate-400">
             Halaman {page} dari {totalPages}
           </span>
           <div className="flex gap-2">
             <button
               disabled={page === 1}
               onClick={() => setPage(p => p - 1)}
               className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed"
             >
               <ChevronLeft className="w-5 h-5" />
             </button>
             <button
               disabled={page === totalPages}
               onClick={() => setPage(p => p + 1)}
               className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed"
             >
               <ChevronRight className="w-5 h-5" />
             </button>
           </div>
        </div>
      )}
    </div>
  );
};
