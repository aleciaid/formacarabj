import { EventData } from '../types';

const WEBHOOK_GET_URL = import.meta.env.VITE_WEBHOOK_GET_URL;
const WEBHOOK_POST_URL = import.meta.env.VITE_WEBHOOK_POST_URL;

interface WebhookResponseItem {
  row_number: number;
  id: number;
  "nama acara": string;
  tanggal: string;
  waktu: string;
  lokasi: string;
  dresscode: string;
  note: string;
}

export const api = {
  getEvents: async (): Promise<EventData[]> => {
    if (!WEBHOOK_GET_URL) {
      throw new Error('VITE_WEBHOOK_GET_URL is not defined in environment variables');
    }

    try {
      const response = await fetch(WEBHOOK_GET_URL, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch events: ${response.statusText}`);
      }

      const rawData = await response.json();
      
      let dataToProcess: (WebhookResponseItem | EventData)[] = [];

      // Validation: ensure data is an array
      if (Array.isArray(rawData)) {
        dataToProcess = rawData;
      } else if (rawData && Array.isArray(rawData.data)) {
        dataToProcess = rawData.data;
      } else if (rawData && (rawData.id || rawData['nama acara'])) {
        dataToProcess = [rawData];
      } else {
        console.warn('API returned non-array data:', rawData);
        return [];
      }

      // Map raw webhook data to EventData structure
      return dataToProcess.map((item) => {
        // Handle both possible structures (in case some old data exists or mixed formats)
        // Check if it's the new format with "nama acara" etc
        if ('nama acara' in item) {
           const webhookItem = item as WebhookResponseItem;
           // Construct ISO date string from tanggal (YYYY-MM-DD) and waktu (HH:mm)
           // Ensure we handle cases where date/time might be malformed
           let isoDate = new Date().toISOString();
           if (webhookItem.tanggal && webhookItem.waktu) {
             isoDate = `${webhookItem.tanggal}T${webhookItem.waktu}`;
           }

           return {
             id: String(webhookItem.id),
             namaAcara: webhookItem["nama acara"],
             tanggalWaktu: isoDate,
             lokasi: webhookItem.lokasi,
             dresscode: webhookItem.dresscode,
             note: webhookItem.note,
             createdAt: new Date().toISOString() // Not provided in GET response, use current time
           };
        }
        
        // Fallback for data that might already match the EventData structure (e.g. from local testing or previous format)
        return item as EventData;
      });

    } catch (error) {
      console.error('API Error:', error);
      throw error;
    }
  },

  createEvent: async (event: EventData): Promise<void> => {
    if (!WEBHOOK_POST_URL) {
      throw new Error('VITE_WEBHOOK_POST_URL is not defined');
    }

    const response = await fetch(WEBHOOK_POST_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(event),
    });

    if (!response.ok) {
      throw new Error(`Failed to create event: ${response.statusText}`);
    }
  }
};
