import { EventData } from '../types';

const STORAGE_KEY = 'event_mgt_data';
const SYNC_KEY = 'event_mgt_last_sync';

export const storage = {
  getEvents: (): EventData[] => {
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Error reading from local storage', error);
      return [];
    }
  },

  saveEvents: (events: EventData[]) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(events));
    } catch (error) {
      console.error('Error saving to local storage', error);
    }
  },

  getLastSync: (): number | null => {
    const time = localStorage.getItem(SYNC_KEY);
    return time ? parseInt(time, 10) : null;
  },

  setLastSync: (timestamp: number) => {
    localStorage.setItem(SYNC_KEY, timestamp.toString());
  },

  invalidateSync: () => {
    localStorage.removeItem(SYNC_KEY);
  }
};
