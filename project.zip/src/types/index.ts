export type Dresscode = 'Formal' | 'Semi-Formal' | 'Casual' | 'Tradisional';

export interface EventData {
  id: string;
  namaAcara: string;
  tanggalWaktu: string;
  lokasi: string;
  dresscode: Dresscode | string;
  note: string;
  createdAt: string;
}
