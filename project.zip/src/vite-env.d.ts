/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_WEBHOOK_GET_URL: string
  readonly VITE_WEBHOOK_POST_URL: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}
